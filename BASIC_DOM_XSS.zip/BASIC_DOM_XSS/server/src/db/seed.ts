import Database from 'better-sqlite3';
import { hashPassword } from '../utils/helpers';

export function seedDatabase(db: Database.Database) {
  const userCount = (db.prepare('SELECT COUNT(*) as count FROM users').get() as any).count;
  if (userCount > 0) return;

  console.log('Seeding database with demo data...');

  const insertUser = db.prepare(
    'INSERT INTO users (username, email, password, display_name, bio) VALUES (?, ?, ?, ?, ?)'
  );

  const insertPost = db.prepare(
    'INSERT INTO posts (user_id, title, body) VALUES (?, ?, ?)'
  );

  const insertFollow = db.prepare(
    'INSERT INTO follows (follower_id, following_id) VALUES (?, ?)'
  );

  const seed = db.transaction(() => {
    // Create users (password: password123)
    const pwd = hashPassword('password123');

    insertUser.run('alice', 'alice@chirp.local', pwd, 'Alice Johnson', 'Full-stack developer & coffee enthusiast');
    insertUser.run('bob', 'bob@chirp.local', pwd, 'Bob Smith', 'UX Designer at TechCorp. Love minimalist design.');
    insertUser.run('charlie', 'charlie@chirp.local', pwd, 'Charlie Davis', 'DevOps engineer. Automation is my passion.');

    // Create follow relationships
    insertFollow.run(1, 2); // alice follows bob
    insertFollow.run(1, 3); // alice follows charlie
    insertFollow.run(2, 1); // bob follows alice
    insertFollow.run(2, 3); // bob follows charlie
    insertFollow.run(3, 1); // charlie follows alice

    // Create posts
    insertPost.run(1, 'Getting started with React', 'Just finished setting up my new React project with Vite. The developer experience is amazing compared to CRA!');
    insertPost.run(2, 'Design tip of the day', 'Less is more. White space is your friend. Let your content breathe.');
    insertPost.run(1, 'TypeScript tips', 'Always define your interfaces before implementing. It forces you to think about the API contract first.');
    insertPost.run(3, 'Docker best practices', 'Use <b>multi-stage builds</b> to keep your production images small. Also, always pin your base image versions!');
    insertPost.run(2, 'New portfolio site', 'Finally launched my new portfolio! Built with Next.js and deployed on Vercel. Check it out!');
    insertPost.run(3, 'CI/CD Pipeline update', 'Migrated our pipeline to GitHub Actions. The YAML syntax is <i>much cleaner</i> than our old Jenkins setup.');
    insertPost.run(1, 'Weekend project ideas', 'Thinking about building a social media app this weekend. Any suggestions for the tech stack?');
  });

  seed();
  console.log('Database seeded successfully!');
}
