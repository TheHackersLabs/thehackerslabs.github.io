import { Router, Response } from 'express';
import { getDatabase } from '../db/database';
import { authMiddleware, AuthRequest } from '../middleware/auth';

const router = Router();

// Follow a user
router.post('/:id', authMiddleware, (req: AuthRequest, res: Response) => {
  const targetId = parseInt(req.params.id as string);

  if (targetId === req.user!.id) {
    return res.status(400).json({ error: 'Cannot follow yourself' });
  }

  const db = getDatabase();

  const target = db.prepare('SELECT id FROM users WHERE id = ?').get(targetId);
  if (!target) {
    return res.status(404).json({ error: 'User not found' });
  }

  const existing = db.prepare(
    'SELECT 1 FROM follows WHERE follower_id = ? AND following_id = ?'
  ).get(req.user!.id, targetId);

  if (existing) {
    return res.status(409).json({ error: 'Already following this user' });
  }

  db.prepare('INSERT INTO follows (follower_id, following_id) VALUES (?, ?)').run(req.user!.id, targetId);

  res.status(201).json({ message: 'Followed successfully' });
});

// Unfollow a user
router.delete('/:id', authMiddleware, (req: AuthRequest, res: Response) => {
  const targetId = parseInt(req.params.id as string);
  const db = getDatabase();

  db.prepare('DELETE FROM follows WHERE follower_id = ? AND following_id = ?').run(req.user!.id, targetId);

  res.json({ message: 'Unfollowed successfully' });
});

// Get who current user follows
router.get('/following', authMiddleware, (req: AuthRequest, res: Response) => {
  const db = getDatabase();
  const following = db.prepare(`
    SELECT u.id, u.username, u.display_name, u.bio, u.avatar_url
    FROM follows f
    JOIN users u ON f.following_id = u.id
    WHERE f.follower_id = ?
  `).all(req.user!.id);

  res.json({ following });
});

// Get current user's followers
router.get('/followers', authMiddleware, (req: AuthRequest, res: Response) => {
  const db = getDatabase();
  const followers = db.prepare(`
    SELECT u.id, u.username, u.display_name, u.bio, u.avatar_url
    FROM follows f
    JOIN users u ON f.follower_id = u.id
    WHERE f.following_id = ?
  `).all(req.user!.id);

  res.json({ followers });
});

export default router;
