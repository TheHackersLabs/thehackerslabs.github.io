import { Router, Request, Response } from 'express';
import { getDatabase } from '../db/database';
import { authMiddleware, AuthRequest } from '../middleware/auth';
import { sanitize } from '../middleware/sanitize';

const router = Router();

// Get feed — posts from followed users + own posts
router.get('/feed', authMiddleware, (req: AuthRequest, res: Response) => {
  const db = getDatabase();
  const posts = db.prepare(`
    SELECT p.*, u.username, u.display_name, u.avatar_url
    FROM posts p
    JOIN users u ON p.user_id = u.id
    WHERE p.user_id IN (
      SELECT following_id FROM follows WHERE follower_id = ?
    ) OR p.user_id = ?
    ORDER BY p.created_at DESC
    LIMIT 50
  `).all(req.user!.id, req.user!.id);

  res.json({ posts });
});

// Get explore — all recent posts (public)
router.get('/explore', (_req: Request, res: Response) => {
  const db = getDatabase();
  const posts = db.prepare(`
    SELECT p.*, u.username, u.display_name, u.avatar_url
    FROM posts p
    JOIN users u ON p.user_id = u.id
    ORDER BY p.created_at DESC
    LIMIT 50
  `).all();

  res.json({ posts });
});

// Create a new post
router.post('/', authMiddleware, (req: AuthRequest, res: Response) => {
  const { title, body } = req.body;

  if (!title || !body) {
    return res.status(400).json({ error: 'Title and body are required' });
  }

  if (title.length > 100) {
    return res.status(400).json({ error: 'Title must be under 100 characters' });
  }

  // Both title and body are sanitized to prevent XSS
  const sanitizedTitle = sanitize(title);
  const sanitizedBody = sanitize(body);

  const db = getDatabase();
  const result = db.prepare(
    'INSERT INTO posts (user_id, title, body) VALUES (?, ?, ?)'
  ).run(req.user!.id, sanitizedTitle, sanitizedBody);

  const post = db.prepare(`
    SELECT p.*, u.username, u.display_name, u.avatar_url
    FROM posts p
    JOIN users u ON p.user_id = u.id
    WHERE p.id = ?
  `).get(result.lastInsertRowid);

  res.status(201).json({ post });
});

// Get a single post
router.get('/:id', authMiddleware, (req: AuthRequest, res: Response) => {
  const db = getDatabase();
  const post = db.prepare(`
    SELECT p.*, u.username, u.display_name, u.avatar_url
    FROM posts p
    JOIN users u ON p.user_id = u.id
    WHERE p.id = ?
  `).get(req.params.id);

  if (!post) {
    return res.status(404).json({ error: 'Post not found' });
  }

  res.json({ post });
});

export default router;
