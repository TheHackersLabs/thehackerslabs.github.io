import { Router, Request, Response } from 'express';
import { getDatabase } from '../db/database';
import { optionalAuthMiddleware, AuthRequest } from '../middleware/auth';

const router = Router();

// List all users (public)
router.get('/', (_req: Request, res: Response) => {
  const db = getDatabase();
  const users = db.prepare(`
    SELECT id, username, display_name, bio, avatar_url, created_at,
      (SELECT COUNT(*) FROM follows WHERE following_id = users.id) as followers_count,
      (SELECT COUNT(*) FROM follows WHERE follower_id = users.id) as following_count
    FROM users
    ORDER BY created_at DESC
  `).all();

  res.json({ users });
});

// Get user profile (public, with optional auth for is_following)
router.get('/:id', optionalAuthMiddleware, (req: AuthRequest, res: Response) => {
  const db = getDatabase();
  const user = db.prepare(`
    SELECT id, username, display_name, bio, avatar_url, created_at,
      (SELECT COUNT(*) FROM follows WHERE following_id = users.id) as followers_count,
      (SELECT COUNT(*) FROM follows WHERE follower_id = users.id) as following_count
    FROM users
    WHERE id = ?
  `).get(req.params.id) as any;

  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  if (req.user) {
    const isFollowing = db.prepare(
      'SELECT 1 FROM follows WHERE follower_id = ? AND following_id = ?'
    ).get(req.user.id, req.params.id);
    user.is_following = !!isFollowing;
  } else {
    user.is_following = false;
  }

  res.json({ user });
});

// Get user's posts (public)
router.get('/:id/posts', (_req: Request, res: Response) => {
  const db = getDatabase();
  const posts = db.prepare(`
    SELECT p.*, u.username, u.display_name, u.avatar_url
    FROM posts p
    JOIN users u ON p.user_id = u.id
    WHERE p.user_id = ?
    ORDER BY p.created_at DESC
  `).all(_req.params.id);

  res.json({ posts });
});

export default router;
