# Chirp - DOM-Based XSS Lab

A realistic social network application built for **educational purposes** to teach DOM-based Cross-Site Scripting (XSS) vulnerabilities through 6 progressive challenges.

> **WARNING:** This application contains **intentional security vulnerabilities**. It is designed for educational use only. Do NOT deploy this in a production environment.

---

## Quick Start

### Using Docker (recommended)

```bash
docker compose up --build
```

Open your browser at **http://localhost:1000**

### Manual Setup (development)

```bash
# Terminal 1 - Backend
cd server
npm install
npm run dev

# Terminal 2 - Frontend
cd client
npm install
npm run dev
```

Open your browser at **http://localhost:5173**

---

## Pre-loaded Accounts

| Username | Display Name | Password |
|----------|-------------|----------|
| `alice` | Alice Johnson | `password123` |
| `bob` | Bob Smith | `password123` |
| `charlie` | Charlie Davis | `password123` |

---

## Lab Overview

This lab contains **6 DOM XSS challenges**, each demonstrating a different source/sink combination. Navigate to `/challenges` to see them all.

| # | Source | Sink | Difficulty |
|---|--------|------|------------|
| 1 | `location.hash` | `innerHTML` | Easy |
| 2 | `URLSearchParams` | iframe `srcdoc` | Easy |
| 3 | URL query param | `eval()` | Medium |
| 4 | URL query param | `setTimeout()` | Medium |
| 5 | URL query param | `location.href` | Medium |
| 6 | `postMessage` | `innerHTML` | Hard |

### What is DOM-based XSS?

Unlike Stored or Reflected XSS, the payload **never reaches the server**. The vulnerable JavaScript code in the browser reads attacker-controlled data (from the URL, hash, postMessage, etc.) and passes it to a dangerous sink (innerHTML, eval, etc.).

---

## Writeup

The complete solution for all 6 challenges is available **inside the app** at `/writeup`.

---

## Hints

<details>
<summary>Challenge 1 Hint</summary>
Look at the URL hash fragment. What happens when you change it?
</details>

<details>
<summary>Challenge 2 Hint</summary>
The <code>name</code> parameter is embedded in an HTML document. What if you include HTML tags?
</details>

<details>
<summary>Challenge 3 Hint</summary>
The expression is evaluated with a very powerful JavaScript function. Which one?
</details>

<details>
<summary>Challenge 4 Hint</summary>
How does <code>setTimeout</code> behave when it receives a string instead of a function?
</details>

<details>
<summary>Challenge 5 Hint</summary>
Not all URL protocols are safe. What does the <code>javascript:</code> protocol do?
</details>

<details>
<summary>Challenge 6 Hint</summary>
Is the widget checking who sent the message? What data format does it expect?
</details>

---

## Tech Stack

- **Frontend:** React + TypeScript + Vite
- **Backend:** Node.js + Express + better-sqlite3
- **Auth:** JWT in httpOnly cookies
- **Container:** Docker multi-stage build

---

## Disclaimer

This lab is designed solely for **educational and authorized security testing purposes**. The vulnerabilities are intentional and serve as learning tools. Never test for vulnerabilities on systems you don't have explicit permission to test.
