// Challenge 2: DOM XSS via iframe srcdoc + URL parameter
// Source: URLSearchParams (name)
// Sink: iframe.srcdoc (equivalent to document.write)

var params = new URLSearchParams(window.location.search);
var name = params.get('name') || '';

var iframe = document.getElementById('challenge-iframe');
if (iframe) {
  var initial = name ? name.charAt(0).toUpperCase() : '?';
  var displayName = name || 'Anonymous';

  var html = '<!DOCTYPE html>' +
    '<html><body style="margin:0;background:#16181c;color:#e7e9ea;' +
    'font-family:-apple-system,BlinkMacSystemFont,Segoe UI,Roboto,sans-serif;' +
    'padding:24px;display:flex;align-items:center;gap:16px">' +
    '<div style="width:48px;height:48px;border-radius:50%;background:#1d9bf0;' +
    'display:flex;align-items:center;justify-content:center;font-weight:bold;' +
    'font-size:20px;color:white;flex-shrink:0">' + initial + '</div>' +
    '<div><div style="font-weight:700;font-size:18px">' + displayName + '</div>' +
    '<div style="color:#71767b;font-size:14px">Chirp User Profile Card</div>' +
    '</div></body></html>';

  iframe.srcdoc = html;
}
