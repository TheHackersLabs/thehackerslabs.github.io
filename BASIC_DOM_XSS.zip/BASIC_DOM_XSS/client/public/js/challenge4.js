// Challenge 4: DOM XSS via setTimeout() with string argument
// Source: URLSearchParams (callback)
// Sink: setTimeout() — string argument is evaluated like eval()

var params = new URLSearchParams(window.location.search);
var callback = params.get('callback') || '';

if (callback) {
  var status = document.getElementById('challenge-status');
  if (status) {
    status.textContent = 'Scheduling notification...';
  }

  setTimeout(callback, 2000);

  setTimeout(function () {
    if (status) {
      status.textContent = 'Callback executed!';
    }
  }, 2100);
}
