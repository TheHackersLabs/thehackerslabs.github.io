// Challenge 3: DOM XSS via eval() + URL parameter
// Source: URLSearchParams (expr)
// Sink: eval()

var params = new URLSearchParams(window.location.search);
var expr = params.get('expr') || '';

if (expr) {
  try {
    var result = eval(expr);
    var output = document.getElementById('challenge-result');
    if (output) {
      output.textContent = String(result);
    }
  } catch (e) {
    var output = document.getElementById('challenge-result');
    if (output) {
      output.textContent = 'Error: ' + e.message;
    }
  }
}
