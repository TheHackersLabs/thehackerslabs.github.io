// Challenge 6: DOM XSS via postMessage + innerHTML
// Source: window.addEventListener('message', ...)
// Sink: innerHTML — no origin validation, no sanitization

window.addEventListener('message', function (event) {
  var widget = document.getElementById('challenge-widget');
  if (widget) {
    widget.innerHTML = event.data;
  }
});
