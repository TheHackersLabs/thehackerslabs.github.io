// Challenge 5: DOM XSS via location.href + javascript: protocol
// Source: URLSearchParams (url)
// Sink: window.location.href — javascript: URLs execute code

var params = new URLSearchParams(window.location.search);
var url = params.get('url') || '';

if (url) {
  var display = document.getElementById('challenge-url-display');
  if (display) {
    display.textContent = url;
  }

  var btn = document.getElementById('challenge-redirect-btn');
  if (btn) {
    btn.addEventListener('click', function () {
      window.location.href = url;
    });
  }

  // Auto-redirect countdown
  var count = 3;
  var counter = document.getElementById('challenge-countdown');
  var interval = setInterval(function () {
    count--;
    if (counter) counter.textContent = count;
    if (count <= 0) {
      clearInterval(interval);
      window.location.href = url;
    }
  }, 1000);
}
