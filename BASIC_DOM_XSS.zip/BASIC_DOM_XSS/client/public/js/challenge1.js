// Challenge 1: DOM XSS via innerHTML + location.hash
// Source: location.hash
// Sink: innerHTML

function updatePreview() {
  var hash = decodeURIComponent(window.location.hash.substring(1));
  var preview = document.getElementById('challenge-output');
  if (preview) {
    preview.innerHTML = hash || '<span style="color:#71767b">Enter a theme above to preview...</span>';
  }
}

updatePreview();
window.addEventListener('hashchange', updatePreview);
