export default function WriteupPage() {
  return (
    <div className="page writeup-page">
      <div className="page-header">
        <h2>DOM XSS Lab - Writeup</h2>
      </div>

      <div className="writeup-intro">
        <h3>What is DOM-based XSS?</h3>
        <p>DOM-based XSS occurs when JavaScript takes data from an attacker-controllable <strong>source</strong> and passes it to a dangerous <strong>sink</strong> — all happening in the browser without the server being involved.</p>
        <table className="xss-table">
          <thead>
            <tr><th>Type</th><th>Payload Location</th><th>Server Involved?</th><th>Persistence</th></tr>
          </thead>
          <tbody>
            <tr><td>Stored</td><td>Database</td><td>Yes</td><td>Permanent</td></tr>
            <tr><td>Reflected</td><td>URL (server reflects)</td><td>Yes</td><td>Per-request</td></tr>
            <tr><td><strong>DOM-based</strong></td><td><strong>URL / Browser API</strong></td><td><strong>No</strong></td><td><strong>Per-request</strong></td></tr>
          </tbody>
        </table>
      </div>

      <div className="writeup-challenges">
        <details className="writeup-challenge">
          <summary>
            <span className="writeup-num">1</span>
            Challenge 1: innerHTML + location.hash
          </summary>
          <div className="writeup-body">
            <div className="writeup-meta">
              <span className="writeup-tag">Source: location.hash</span>
              <span className="writeup-tag">Sink: innerHTML</span>
            </div>
            <h4>Vulnerable Code</h4>
            <pre><code>{`const hash = decodeURIComponent(window.location.hash.substring(1));
previewRef.current.innerHTML = hash;`}</code></pre>
            <h4>Payload</h4>
            <pre><code>{`/challenges/1#<img src=x onerror=alert('XSS')>`}</code></pre>
            <h4>Why it works</h4>
            <p>The hash fragment is read from the URL and directly set as <code>innerHTML</code>. The browser parses the HTML, finds the <code>&lt;img&gt;</code> tag with an invalid src, and fires the <code>onerror</code> handler. Hash fragments are never sent to the server, making this purely DOM-based.</p>
            <h4>Fix</h4>
            <pre><code>{`// Use textContent instead of innerHTML
previewRef.current.textContent = hash;

// Or sanitize with DOMPurify
previewRef.current.innerHTML = DOMPurify.sanitize(hash);`}</code></pre>
          </div>
        </details>

        <details className="writeup-challenge">
          <summary>
            <span className="writeup-num">2</span>
            Challenge 2: iframe srcdoc + URL parameter
          </summary>
          <div className="writeup-body">
            <div className="writeup-meta">
              <span className="writeup-tag">Source: URLSearchParams</span>
              <span className="writeup-tag">Sink: iframe srcdoc</span>
            </div>
            <h4>Vulnerable Code</h4>
            <pre><code>{`const name = searchParams.get('name') || '';
const cardHtml = \`<div>\${name}</div>\`;
// Rendered as: <iframe srcdoc={cardHtml} />`}</code></pre>
            <h4>Payload</h4>
            <pre><code>{`/challenges/2?name=<script>alert('XSS')</script>`}</code></pre>
            <h4>Why it works</h4>
            <p>The <code>name</code> parameter is interpolated directly into an HTML string used as the iframe's <code>srcdoc</code>. This is equivalent to <code>document.write()</code> — the browser creates a new document from the HTML string, executing any <code>&lt;script&gt;</code> tags it finds.</p>
            <h4>Fix</h4>
            <pre><code>{`// Escape HTML entities before interpolation
function escapeHtml(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
const cardHtml = \`<div>\${escapeHtml(name)}</div>\`;`}</code></pre>
          </div>
        </details>

        <details className="writeup-challenge">
          <summary>
            <span className="writeup-num">3</span>
            Challenge 3: eval() + URL parameter
          </summary>
          <div className="writeup-body">
            <div className="writeup-meta">
              <span className="writeup-tag">Source: URL query param</span>
              <span className="writeup-tag">Sink: eval()</span>
            </div>
            <h4>Vulnerable Code</h4>
            <pre><code>{`const expr = searchParams.get('expr') || '';
const result = eval(expr); // Executes any JavaScript`}</code></pre>
            <h4>Payload</h4>
            <pre><code>{`/challenges/3?expr=alert('XSS')`}</code></pre>
            <h4>Why it works</h4>
            <p><code>eval()</code> executes any string as JavaScript code. The expression parameter from the URL is passed directly to eval, allowing arbitrary code execution. This is one of the most dangerous sinks.</p>
            <h4>Fix</h4>
            <pre><code>{`// Never use eval() with user input
// For math expressions, use a safe parser library
// Or validate against a strict whitelist:
if (/^[0-9+\\-*/().\\s]+$/.test(expr)) {
  const result = Function('"use strict"; return (' + expr + ')')();
}`}</code></pre>
          </div>
        </details>

        <details className="writeup-challenge">
          <summary>
            <span className="writeup-num">4</span>
            Challenge 4: setTimeout() + URL parameter
          </summary>
          <div className="writeup-body">
            <div className="writeup-meta">
              <span className="writeup-tag">Source: URL query param</span>
              <span className="writeup-tag">Sink: setTimeout()</span>
            </div>
            <h4>Vulnerable Code</h4>
            <pre><code>{`const callback = searchParams.get('callback') || '';
setTimeout(callback, 2000); // String argument = eval()`}</code></pre>
            <h4>Payload</h4>
            <pre><code>{`/challenges/4?callback=alert('XSS')`}</code></pre>
            <h4>Why it works</h4>
            <p>When <code>setTimeout()</code> receives a <strong>string</strong> as its first argument (instead of a function), it evaluates the string as JavaScript code — effectively the same as <code>eval()</code>. The same applies to <code>setInterval()</code>.</p>
            <h4>Fix</h4>
            <pre><code>{`// Never pass strings to setTimeout/setInterval
// Use function references instead:
const callbacks = { notify: () => showNotification() };
if (callbacks[callbackName]) {
  setTimeout(callbacks[callbackName], 2000);
}`}</code></pre>
          </div>
        </details>

        <details className="writeup-challenge">
          <summary>
            <span className="writeup-num">5</span>
            Challenge 5: location.href + javascript: protocol
          </summary>
          <div className="writeup-body">
            <div className="writeup-meta">
              <span className="writeup-tag">Source: URL query param</span>
              <span className="writeup-tag">Sink: location.href</span>
            </div>
            <h4>Vulnerable Code</h4>
            <pre><code>{`const url = searchParams.get('url') || '';
window.location.href = url; // javascript: URLs execute code`}</code></pre>
            <h4>Payload</h4>
            <pre><code>{`/challenges/5?url=javascript:alert('XSS')`}</code></pre>
            <h4>Why it works</h4>
            <p>Assigning a <code>javascript:</code> URL to <code>window.location.href</code> executes the JavaScript code after the protocol prefix. This also works with <code>location.assign()</code>, <code>location.replace()</code>, and <code>&lt;a href&gt;</code> elements.</p>
            <h4>Fix</h4>
            <pre><code>{`// Validate the URL protocol before redirecting
const parsed = new URL(url, window.location.origin);
if (parsed.protocol === 'http:' || parsed.protocol === 'https:') {
  window.location.href = url;
}`}</code></pre>
          </div>
        </details>

        <details className="writeup-challenge">
          <summary>
            <span className="writeup-num">6</span>
            Challenge 6: postMessage + innerHTML
          </summary>
          <div className="writeup-body">
            <div className="writeup-meta">
              <span className="writeup-tag">Source: postMessage</span>
              <span className="writeup-tag">Sink: innerHTML</span>
            </div>
            <h4>Vulnerable Code</h4>
            <pre><code>{`window.addEventListener('message', (event) => {
  // No origin check!
  widgetRef.current.innerHTML = event.data;
});`}</code></pre>
            <h4>Payload</h4>
            <pre><code>{`// From the test console or browser devtools:
window.postMessage('<img src=x onerror=alert("XSS")>', '*')

// From an attacker page:
const w = window.open('http://localhost:1000/challenges/6');
setTimeout(() => w.postMessage('<img src=x onerror=alert("XSS")>', '*'), 1000);`}</code></pre>
            <h4>Why it works</h4>
            <p>The widget listens for <code>message</code> events but doesn't check the <strong>origin</strong> of the sender. Any page (including attacker-controlled pages) can send messages. The received data is set as <code>innerHTML</code> without sanitization, allowing HTML injection.</p>
            <h4>Fix</h4>
            <pre><code>{`window.addEventListener('message', (event) => {
  // Validate the origin
  if (event.origin !== 'https://trusted-domain.com') return;
  // Sanitize the data
  widgetRef.current.textContent = event.data;
});`}</code></pre>
          </div>
        </details>
      </div>

      <div className="writeup-takeaways">
        <h3>Key Takeaways</h3>
        <ul>
          <li><strong>DOM XSS is invisible to the server.</strong> WAFs and server-side sanitization cannot prevent it.</li>
          <li><strong>Dangerous sinks:</strong> <code>innerHTML</code>, <code>eval()</code>, <code>setTimeout(string)</code>, <code>document.write()</code>, <code>location.href</code></li>
          <li><strong>Dangerous sources:</strong> <code>location.hash</code>, <code>location.search</code>, <code>document.referrer</code>, <code>postMessage</code></li>
          <li><strong>Always validate and sanitize</strong> data from any client-side source before passing it to a sink.</li>
          <li><strong>Use CSP headers</strong> as defense in depth to block inline scripts and <code>eval()</code>.</li>
          <li><strong>Prefer safe APIs:</strong> <code>textContent</code> over <code>innerHTML</code>, function references over string arguments in timers.</li>
        </ul>
      </div>
    </div>
  );
}
