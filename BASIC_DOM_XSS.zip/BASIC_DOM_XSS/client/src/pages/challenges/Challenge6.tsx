import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

export default function Challenge6() {
  const [input, setInput] = useState('');
  const [log, setLog] = useState<string[]>([]);

  useEffect(() => {
    const script = document.createElement('script');
    script.src = '/js/challenge6.js';
    document.body.appendChild(script);

    const logHandler = (event: MessageEvent) => {
      setLog(prev => [...prev, `Received: ${String(event.data).substring(0, 100)}`]);
    };
    window.addEventListener('message', logHandler);

    return () => {
      document.body.removeChild(script);
      window.removeEventListener('message', logHandler);
    };
  }, []);

  const handleSend = () => {
    if (input) {
      window.postMessage(input, '*');
      setInput('');
    }
  };

  return (
    <div className="page">
      <div className="page-header">
        <h2>Challenge 6: Widget Embed</h2>
      </div>
      <div className="challenge-scenario">
        <p>Chirp provides an embeddable widget that listens for <code>postMessage</code> events to receive content from parent pages. The widget renders any received message to update its display.</p>
        <p className="text-secondary text-sm" style={{ marginTop: 8 }}>Vulnerable script: <code>/js/challenge6.js</code></p>
      </div>
      <div className="challenge-playground">
        <label className="text-secondary text-sm">Widget Display</label>
        <div id="challenge-widget" className="challenge-output" style={{ minHeight: 80 }}>
          <span style={{ color: 'var(--text-secondary)' }}>Waiting for messages...</span>
        </div>

        <div style={{ marginTop: 16, borderTop: '1px solid var(--border)', paddingTop: 16 }}>
          <label className="text-secondary text-sm">Test Console</label>
          <p className="text-secondary text-sm" style={{ marginBottom: 8 }}>
            Simulate sending a postMessage to the widget. In a real attack, this would come from an attacker-controlled page.
          </p>
          <div style={{ display: 'flex', gap: 8 }}>
            <input
              type="text"
              className="input"
              placeholder="Enter message content..."
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSend()}
            />
            <button onClick={handleSend} className="btn btn-primary">Send</button>
          </div>
        </div>

        {log.length > 0 && (
          <div style={{ marginTop: 16 }}>
            <label className="text-secondary text-sm">Message Log</label>
            <div className="challenge-output" style={{ fontFamily: 'monospace', fontSize: 13 }}>
              {log.map((entry, i) => (
                <div key={i}>{entry}</div>
              ))}
            </div>
          </div>
        )}
      </div>
      <div className="challenge-hints">
        <details>
          <summary>Hint 1</summary>
          <p>The widget listens for messages and renders them. Is there any origin validation?</p>
        </details>
        <details>
          <summary>Hint 2</summary>
          <p>The received data is set as <code>innerHTML</code> without sanitization.</p>
        </details>
        <details>
          <summary>Hint 3</summary>
          <p>Send: <code>&lt;img src=x onerror=alert('XSS')&gt;</code></p>
        </details>
      </div>
      <div style={{ padding: 16 }}>
        <Link to="/challenges" className="btn btn-outline btn-sm">Back to Challenges</Link>
      </div>
    </div>
  );
}
