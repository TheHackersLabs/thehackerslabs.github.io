import { useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';

export default function Challenge2() {
  const [searchParams] = useSearchParams();
  const name = searchParams.get('name') || '';

  useEffect(() => {
    const script = document.createElement('script');
    script.src = '/js/challenge2.js';
    document.body.appendChild(script);
    return () => { document.body.removeChild(script); };
  }, []);

  return (
    <div className="page">
      <div className="page-header">
        <h2>Challenge 2: Share Profile Card</h2>
      </div>
      <div className="challenge-scenario">
        <p>Chirp lets users generate shareable profile cards. The user's name is read from the URL so cards can be shared as links. Try adding <code>?name=YourName</code> to the URL.</p>
        <p className="text-secondary text-sm" style={{ marginTop: 8 }}>Vulnerable script: <code>/js/challenge2.js</code></p>
      </div>
      <div className="challenge-playground">
        <label className="text-secondary text-sm">Generated Share Card</label>
        <iframe
          id="challenge-iframe"
          title="Share Card Preview"
          className="challenge-iframe"
          sandbox="allow-scripts allow-modals"
        />
        <p className="text-secondary text-sm" style={{ marginTop: 8 }}>
          Current name: <code>{name || '(empty)'}</code>
        </p>
      </div>
      <div className="challenge-hints">
        <details>
          <summary>Hint 1</summary>
          <p>The <code>name</code> parameter is embedded directly into the HTML of the iframe.</p>
        </details>
        <details>
          <summary>Hint 2</summary>
          <p>What happens if you put HTML tags in the name parameter?</p>
        </details>
        <details>
          <summary>Hint 3</summary>
          <p>Try: <code>?name=&lt;script&gt;alert('XSS')&lt;/script&gt;</code></p>
        </details>
      </div>
      <div style={{ padding: 16 }}>
        <Link to="/challenges" className="btn btn-outline btn-sm">Back to Challenges</Link>
      </div>
    </div>
  );
}
