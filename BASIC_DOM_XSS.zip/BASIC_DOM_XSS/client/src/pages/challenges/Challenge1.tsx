import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';

export default function Challenge1() {
  const [input, setInput] = useState('');

  useEffect(() => {
    const script = document.createElement('script');
    script.src = '/js/challenge1.js';
    document.body.appendChild(script);
    return () => { document.body.removeChild(script); };
  }, []);

  const handleInput = (value: string) => {
    setInput(value);
    window.location.hash = encodeURIComponent(value);
  };

  return (
    <div className="page">
      <div className="page-header">
        <h2>Challenge 1: Theme Preview</h2>
      </div>
      <div className="challenge-scenario">
        <p>Chirp allows users to preview custom widget themes. The theme content is loaded from the URL hash fragment so users can share theme links with each other.</p>
        <p className="text-secondary text-sm" style={{ marginTop: 8 }}>Vulnerable script: <code>/js/challenge1.js</code></p>
      </div>
      <div className="challenge-playground">
        <label className="text-secondary text-sm">Theme Content</label>
        <input
          type="text"
          className="input"
          placeholder="Enter HTML theme content..."
          value={input}
          onChange={e => handleInput(e.target.value)}
        />
        <label className="text-secondary text-sm" style={{ marginTop: 16, display: 'block' }}>Preview</label>
        <div id="challenge-output" className="challenge-output" />
      </div>
      <div className="challenge-hints">
        <details>
          <summary>Hint 1</summary>
          <p>Look at the URL. What happens to the hash fragment?</p>
        </details>
        <details>
          <summary>Hint 2</summary>
          <p>The hash content is rendered as HTML. What if you put HTML tags in it?</p>
        </details>
        <details>
          <summary>Hint 3</summary>
          <p>Try: <code>#&lt;img src=x onerror=alert('XSS')&gt;</code></p>
        </details>
      </div>
      <div style={{ padding: 16 }}>
        <Link to="/challenges" className="btn btn-outline btn-sm">Back to Challenges</Link>
      </div>
    </div>
  );
}
