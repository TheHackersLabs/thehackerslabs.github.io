import { useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';

export default function Challenge5() {
  const [searchParams] = useSearchParams();
  const url = searchParams.get('url') || '';

  useEffect(() => {
    if (url) {
      const script = document.createElement('script');
      script.src = '/js/challenge5.js';
      document.body.appendChild(script);
      return () => { document.body.removeChild(script); };
    }
  }, [url]);

  return (
    <div className="page">
      <div className="page-header">
        <h2>Challenge 5: External Link Handler</h2>
      </div>
      <div className="challenge-scenario">
        <p>Chirp uses a link handler to redirect users to external websites. The destination URL is provided via the <code>url</code> query parameter. Add <code>?url=https://example.com</code> to try it.</p>
        <p className="text-secondary text-sm" style={{ marginTop: 8 }}>Vulnerable script: <code>/js/challenge5.js</code></p>
      </div>
      <div className="challenge-playground">
        {url ? (
          <div style={{ textAlign: 'center', padding: 24 }}>
            <p className="text-secondary" style={{ marginBottom: 8 }}>You are being redirected to:</p>
            <p id="challenge-url-display" style={{ fontFamily: 'monospace', fontSize: 16, wordBreak: 'break-all', marginBottom: 16 }}></p>
            <p id="challenge-countdown" style={{ fontSize: 48, fontWeight: 800, color: 'var(--accent)', marginBottom: 16 }}>3</p>
            <button id="challenge-redirect-btn" className="btn btn-primary">Redirect Now</button>
          </div>
        ) : (
          <div className="challenge-output">
            <p className="text-secondary">No URL specified. Add <code>?url=...</code> to the URL.</p>
          </div>
        )}
      </div>
      <div className="challenge-hints">
        <details>
          <summary>Hint 1</summary>
          <p>The URL parameter is assigned directly to <code>window.location.href</code>. Are all URL protocols safe?</p>
        </details>
        <details>
          <summary>Hint 2</summary>
          <p>The <code>javascript:</code> protocol executes code when used in navigation.</p>
        </details>
        <details>
          <summary>Hint 3</summary>
          <p>Try: <code>?url=javascript:alert('XSS')</code></p>
        </details>
      </div>
      <div style={{ padding: 16 }}>
        <Link to="/challenges" className="btn btn-outline btn-sm">Back to Challenges</Link>
      </div>
    </div>
  );
}
