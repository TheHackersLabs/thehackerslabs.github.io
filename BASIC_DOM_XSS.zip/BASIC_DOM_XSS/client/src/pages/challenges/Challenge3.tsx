import { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';

export default function Challenge3() {
  const [searchParams, setSearchParams] = useSearchParams();
  const expr = searchParams.get('expr') || '';
  const [input, setInput] = useState(expr);

  useEffect(() => {
    const script = document.createElement('script');
    script.src = '/js/challenge3.js';
    document.body.appendChild(script);
    return () => { document.body.removeChild(script); };
  }, [expr]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchParams({ expr: input });
  };

  return (
    <div className="page">
      <div className="page-header">
        <h2>Challenge 3: Advanced Search</h2>
      </div>
      <div className="challenge-scenario">
        <p>Chirp's advanced search supports filter expressions to help power users query posts. Enter a mathematical or logical expression to filter results (e.g., <code>2+2</code>, <code>posts &gt; 10</code>).</p>
        <p className="text-secondary text-sm" style={{ marginTop: 8 }}>Vulnerable script: <code>/js/challenge3.js</code></p>
      </div>
      <div className="challenge-playground">
        <form onSubmit={handleSubmit}>
          <label className="text-secondary text-sm">Filter Expression</label>
          <div style={{ display: 'flex', gap: 8 }}>
            <input
              type="text"
              className="input"
              placeholder="Enter expression (e.g., 2+2)"
              value={input}
              onChange={e => setInput(e.target.value)}
            />
            <button type="submit" className="btn btn-primary">Evaluate</button>
          </div>
        </form>
        <div className="challenge-output" style={{ marginTop: 16 }}>
          <label className="text-secondary text-sm">Result</label>
          <p id="challenge-result" style={{ fontFamily: 'monospace', fontSize: 16, marginTop: 4 }}></p>
        </div>
      </div>
      <div className="challenge-hints">
        <details>
          <summary>Hint 1</summary>
          <p>The expression from the URL is evaluated using JavaScript. What function does that?</p>
        </details>
        <details>
          <summary>Hint 2</summary>
          <p>If the expression is passed to <code>eval()</code>, you can run any JavaScript code.</p>
        </details>
        <details>
          <summary>Hint 3</summary>
          <p>Try: <code>?expr=alert('XSS')</code></p>
        </details>
      </div>
      <div style={{ padding: 16 }}>
        <Link to="/challenges" className="btn btn-outline btn-sm">Back to Challenges</Link>
      </div>
    </div>
  );
}
