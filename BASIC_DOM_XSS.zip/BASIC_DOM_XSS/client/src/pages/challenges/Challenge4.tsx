import { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';

export default function Challenge4() {
  const [searchParams, setSearchParams] = useSearchParams();
  const callback = searchParams.get('callback') || '';
  const [input, setInput] = useState(callback);

  useEffect(() => {
    const script = document.createElement('script');
    script.src = '/js/challenge4.js';
    document.body.appendChild(script);
    return () => { document.body.removeChild(script); };
  }, [callback]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchParams({ callback: input });
  };

  return (
    <div className="page">
      <div className="page-header">
        <h2>Challenge 4: Notification Scheduler</h2>
      </div>
      <div className="challenge-scenario">
        <p>Chirp's notification system allows scheduling custom notification callbacks via URL parameters. The callback is executed after a 2-second delay.</p>
        <p className="text-secondary text-sm" style={{ marginTop: 8 }}>Vulnerable script: <code>/js/challenge4.js</code></p>
      </div>
      <div className="challenge-playground">
        <form onSubmit={handleSubmit}>
          <label className="text-secondary text-sm">Callback Function</label>
          <div style={{ display: 'flex', gap: 8 }}>
            <input
              type="text"
              className="input"
              placeholder="Enter callback code..."
              value={input}
              onChange={e => setInput(e.target.value)}
            />
            <button type="submit" className="btn btn-primary">Schedule</button>
          </div>
        </form>
        <div className="challenge-output" style={{ marginTop: 16 }}>
          <p id="challenge-status" style={{ fontFamily: 'monospace' }}></p>
        </div>
      </div>
      <div className="challenge-hints">
        <details>
          <summary>Hint 1</summary>
          <p>The callback parameter is passed to a timer function. How does JavaScript handle string arguments in timers?</p>
        </details>
        <details>
          <summary>Hint 2</summary>
          <p><code>setTimeout</code> with a string argument works like <code>eval()</code>.</p>
        </details>
        <details>
          <summary>Hint 3</summary>
          <p>Try: <code>?callback=alert('XSS')</code> and wait 2 seconds.</p>
        </details>
      </div>
      <div style={{ padding: 16 }}>
        <Link to="/challenges" className="btn btn-outline btn-sm">Back to Challenges</Link>
      </div>
    </div>
  );
}
