import { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import api from '../api/client';
import { User, Post } from '../types';
import PostCard from '../components/PostCard';
import FollowButton from '../components/FollowButton';
import { useAuth } from '../context/AuthContext';

function getAvatarColor(name: string): string {
  const colors = ['#1d9bf0', '#7856ff', '#f91880', '#ff7a00', '#00ba7c', '#ffd400'];
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  return colors[Math.abs(hash) % colors.length];
}

export default function ProfilePage() {
  const { id } = useParams<{ id: string }>();
  const { user: currentUser } = useAuth();
  const [profile, setProfile] = useState<User | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchProfile = () => {
    if (!id) return;
    Promise.all([
      api.get(`/users/${id}`),
      api.get(`/users/${id}/posts`),
    ])
      .then(([userRes, postsRes]) => {
        setProfile(userRes.data.user);
        setPosts(postsRes.data.posts);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    setLoading(true);
    fetchProfile();
  }, [id]);

  if (loading) return <div className="loading">Loading profile...</div>;
  if (!profile) return <div className="empty-state">User not found</div>;

  return (
    <div className="page">
      <div className="profile-header">
        <div className="profile-banner" />
        <div className="profile-info">
          <div className="profile-avatar-row">
            <div className="avatar avatar-lg" style={{ backgroundColor: getAvatarColor(profile.display_name) }}>
              {profile.display_name.charAt(0).toUpperCase()}
            </div>
            {currentUser && currentUser.id !== profile.id && (
              <FollowButton userId={profile.id} isFollowing={profile.is_following || false} onToggle={fetchProfile} />
            )}
          </div>
          <h2 className="profile-name">{profile.display_name}</h2>
          <p className="profile-handle">@{profile.username}</p>
          {profile.bio && <p className="profile-bio">{profile.bio}</p>}
          <div className="profile-stats">
            <span><strong>{profile.following_count || 0}</strong> <span className="text-secondary">Following</span></span>
            <span><strong>{profile.followers_count || 0}</strong> <span className="text-secondary">Followers</span></span>
          </div>
        </div>
      </div>
      <div className="page-header">
        <h3>Posts</h3>
      </div>
      {posts.length === 0 ? (
        <div className="empty-state">
          <p className="text-secondary">No posts yet.</p>
        </div>
      ) : (
        <div className="posts-list">
          {posts.map(post => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      )}
    </div>
  );
}
