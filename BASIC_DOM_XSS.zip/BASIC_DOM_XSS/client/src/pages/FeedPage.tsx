import { useState, useEffect } from 'react';
import api from '../api/client';
import { Post } from '../types';
import PostCard from '../components/PostCard';
import PostForm from '../components/PostForm';

export default function FeedPage() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/posts/feed')
      .then(res => setPosts(res.data.posts))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const handleNewPost = (post: Post) => {
    setPosts(prev => [post, ...prev]);
  };

  return (
    <div className="page">
      <div className="page-header">
        <h2>Feed</h2>
      </div>
      <PostForm onPost={handleNewPost} />
      {loading ? (
        <div className="loading">Loading posts...</div>
      ) : posts.length === 0 ? (
        <div className="empty-state">
          <p>Your feed is empty.</p>
          <p className="text-secondary">Follow some users to see their posts here, or check out the Explore page.</p>
        </div>
      ) : (
        <div className="posts-list">
          {posts.map(post => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      )}
    </div>
  );
}
