import { useState, useEffect } from 'react';
import api from '../api/client';
import { Post, User } from '../types';
import PostCard from '../components/PostCard';
import UserCard from '../components/UserCard';

export default function ExplorePage() {
  const [posts, setPosts] = useState<Post[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [tab, setTab] = useState<'posts' | 'users'>('posts');
  const [loading, setLoading] = useState(true);

  const fetchData = () => {
    setLoading(true);
    if (tab === 'posts') {
      api.get('/posts/explore')
        .then(res => setPosts(res.data.posts))
        .catch(() => {})
        .finally(() => setLoading(false));
    } else {
      api.get('/users')
        .then(res => setUsers(res.data.users))
        .catch(() => {})
        .finally(() => setLoading(false));
    }
  };

  useEffect(() => {
    fetchData();
  }, [tab]);

  return (
    <div className="page">
      <div className="page-header">
        <h2>Explore</h2>
      </div>
      <div className="tabs">
        <button
          className={`tab ${tab === 'posts' ? 'active' : ''}`}
          onClick={() => setTab('posts')}
        >
          Posts
        </button>
        <button
          className={`tab ${tab === 'users' ? 'active' : ''}`}
          onClick={() => setTab('users')}
        >
          Users
        </button>
      </div>
      {loading ? (
        <div className="loading">Loading...</div>
      ) : tab === 'posts' ? (
        <div className="posts-list">
          {posts.map(post => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      ) : (
        <div className="users-list">
          {users.map(user => (
            <UserCard key={user.id} user={user} onFollowChange={fetchData} />
          ))}
        </div>
      )}
    </div>
  );
}
