import { Link } from 'react-router-dom';

const challenges = [
  {
    id: 1,
    title: 'Hash Fragment Injection',
    feature: 'Theme Preview',
    description: 'A theme preview feature reads content from the URL hash fragment and renders it on the page.',
    source: 'location.hash',
    sink: 'innerHTML',
    difficulty: 'Easy',
  },
  {
    id: 2,
    title: 'Dynamic Share Card',
    feature: 'Share Profile',
    description: 'A share card generator reads a name from the URL and builds an HTML preview inside an iframe.',
    source: 'URLSearchParams',
    sink: 'iframe srcdoc',
    difficulty: 'Easy',
  },
  {
    id: 3,
    title: 'Expression Evaluator',
    feature: 'Advanced Search',
    description: 'An advanced search feature evaluates filter expressions from the URL to process search queries.',
    source: 'URL query param',
    sink: 'eval()',
    difficulty: 'Medium',
  },
  {
    id: 4,
    title: 'Delayed Callback',
    feature: 'Notifications',
    description: 'A notification system schedules callback functions from URL parameters to run after a delay.',
    source: 'URL query param',
    sink: 'setTimeout()',
    difficulty: 'Medium',
  },
  {
    id: 5,
    title: 'Open Redirect to XSS',
    feature: 'External Links',
    description: 'An external link handler reads a destination URL from query parameters and redirects the user.',
    source: 'URL query param',
    sink: 'location.href',
    difficulty: 'Medium',
  },
  {
    id: 6,
    title: 'Cross-Origin Messaging',
    feature: 'Widget Embed',
    description: 'An embeddable widget listens for cross-origin messages and renders received content on the page.',
    source: 'postMessage',
    sink: 'innerHTML',
    difficulty: 'Hard',
  },
];

function getDifficultyClass(d: string) {
  if (d === 'Easy') return 'difficulty-easy';
  if (d === 'Medium') return 'difficulty-medium';
  return 'difficulty-hard';
}

export default function ChallengesPage() {
  return (
    <div className="page">
      <div className="page-header">
        <h2>DOM XSS Challenges</h2>
      </div>
      <div className="challenges-intro">
        <p>DOM-based XSS occurs entirely in the browser. JavaScript reads data from an attacker-controllable <strong>source</strong> (URL, hash, postMessage) and passes it to a dangerous <strong>sink</strong> (innerHTML, eval, document.write). The payload never reaches the server.</p>
        <p className="text-secondary">Find and exploit the vulnerability in each challenge.</p>
      </div>
      <div className="challenges-grid">
        {challenges.map(c => (
          <Link to={`/challenges/${c.id}`} key={c.id} className="challenge-card">
            <div className="challenge-card-header">
              <span className="challenge-num">{c.id}</span>
              <span className={`challenge-difficulty ${getDifficultyClass(c.difficulty)}`}>{c.difficulty}</span>
            </div>
            <h3 className="challenge-title">{c.title}</h3>
            <p className="challenge-feature text-secondary">{c.feature}</p>
            <p className="challenge-desc">{c.description}</p>
            <div className="challenge-tags">
              <span className="challenge-tag">Source: {c.source}</span>
              <span className="challenge-tag">Sink: {c.sink}</span>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
