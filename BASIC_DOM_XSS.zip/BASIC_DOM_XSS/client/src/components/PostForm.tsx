import { useState } from 'react';
import api from '../api/client';
import { Post } from '../types';
import { useAuth } from '../context/AuthContext';

interface PostFormProps {
  onPost: (post: Post) => void;
}

export default function PostForm({ onPost }: PostFormProps) {
  const { user } = useAuth();
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !body.trim()) return;

    setLoading(true);
    setError('');

    try {
      const res = await api.post('/posts', { title, body });
      onPost(res.data.post);
      setTitle('');
      setBody('');
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to create post');
    } finally {
      setLoading(false);
    }
  };

  if (!user) return null;

  return (
    <form className="post-form" onSubmit={handleSubmit}>
      <div className="post-form-header">
        <div className="avatar avatar-sm" style={{ backgroundColor: '#1d9bf0' }}>
          {user.display_name.charAt(0).toUpperCase()}
        </div>
        <span className="text-secondary">Create a new post</span>
      </div>
      {error && <div className="error-message">{error}</div>}
      <input
        type="text"
        className="input"
        placeholder="Post title"
        value={title}
        onChange={e => setTitle(e.target.value)}
        maxLength={100}
      />
      <textarea
        className="input textarea"
        placeholder="What's on your mind?"
        value={body}
        onChange={e => setBody(e.target.value)}
        rows={3}
      />
      <div className="post-form-footer">
        <div />
        <button type="submit" className="btn btn-primary" disabled={loading || !title.trim() || !body.trim()}>
          {loading ? 'Posting...' : 'Post'}
        </button>
      </div>
    </form>
  );
}
