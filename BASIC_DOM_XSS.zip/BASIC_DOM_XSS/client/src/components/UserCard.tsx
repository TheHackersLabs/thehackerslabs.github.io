import { Link } from 'react-router-dom';
import { User } from '../types';
import FollowButton from './FollowButton';
import { useAuth } from '../context/AuthContext';

function getAvatarColor(name: string): string {
  const colors = ['#1d9bf0', '#7856ff', '#f91880', '#ff7a00', '#00ba7c', '#ffd400'];
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  return colors[Math.abs(hash) % colors.length];
}

interface UserCardProps {
  user: User;
  onFollowChange?: () => void;
}

export default function UserCard({ user: profile, onFollowChange }: UserCardProps) {
  const { user: currentUser } = useAuth();

  return (
    <div className="user-card">
      <Link to={`/profile/${profile.id}`} className="user-card-link">
        <div className="avatar" style={{ backgroundColor: getAvatarColor(profile.display_name) }}>
          {profile.display_name.charAt(0).toUpperCase()}
        </div>
        <div className="user-card-info">
          <span className="user-card-name">{profile.display_name}</span>
          <span className="user-card-handle">@{profile.username}</span>
          {profile.bio && <p className="user-card-bio">{profile.bio}</p>}
        </div>
      </Link>
      {currentUser && currentUser.id !== profile.id && (
        <FollowButton userId={profile.id} isFollowing={profile.is_following || false} onToggle={onFollowChange} />
      )}
    </div>
  );
}
