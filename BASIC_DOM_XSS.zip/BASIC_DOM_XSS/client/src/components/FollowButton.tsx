import { useState } from 'react';
import api from '../api/client';

interface FollowButtonProps {
  userId: number;
  isFollowing: boolean;
  onToggle?: () => void;
}

export default function FollowButton({ userId, isFollowing: initialFollowing, onToggle }: FollowButtonProps) {
  const [following, setFollowing] = useState(initialFollowing);
  const [loading, setLoading] = useState(false);

  const handleClick = async () => {
    setLoading(true);
    try {
      if (following) {
        await api.delete(`/follows/${userId}`);
      } else {
        await api.post(`/follows/${userId}`);
      }
      setFollowing(!following);
      onToggle?.();
    } catch {
      // Ignore errors
    } finally {
      setLoading(false);
    }
  };

  return (
    <button
      onClick={handleClick}
      disabled={loading}
      className={`btn ${following ? 'btn-outline' : 'btn-primary'} btn-sm`}
    >
      {following ? 'Following' : 'Follow'}
    </button>
  );
}
