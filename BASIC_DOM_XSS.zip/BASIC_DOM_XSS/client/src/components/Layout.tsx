import { Outlet } from 'react-router-dom';
import Navbar from './Navbar';

export default function Layout() {
  return (
    <div className="app-layout">
      <aside className="sidebar-left">
        <Navbar />
      </aside>
      <main className="main-content">
        <Outlet />
      </main>
      <aside className="sidebar-right">
        <div className="sidebar-card">
          <h3>About Chirp</h3>
          <p className="text-secondary">Share your thoughts with the world. Connect with developers and creators.</p>
        </div>
      </aside>
    </div>
  );
}
