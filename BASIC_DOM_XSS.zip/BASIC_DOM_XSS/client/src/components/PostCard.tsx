import { Link } from 'react-router-dom';
import { Post } from '../types';

function timeAgo(dateStr: string): string {
  const now = new Date();
  const date = new Date(dateStr);
  const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);

  if (seconds < 60) return 'just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h`;
  if (seconds < 604800) return `${Math.floor(seconds / 86400)}d`;
  return date.toLocaleDateString();
}

function getAvatarColor(name: string): string {
  const colors = ['#1d9bf0', '#7856ff', '#f91880', '#ff7a00', '#00ba7c', '#ffd400'];
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  return colors[Math.abs(hash) % colors.length];
}

export default function PostCard({ post }: { post: Post }) {
  return (
    <article className="post-card">
      <Link to={`/profile/${post.user_id}`} className="post-avatar-link">
        <div className="avatar" style={{ backgroundColor: getAvatarColor(post.display_name) }}>
          {post.display_name.charAt(0).toUpperCase()}
        </div>
      </Link>
      <div className="post-content">
        <div className="post-header">
          <Link to={`/profile/${post.user_id}`} className="post-author">
            <span className="post-display-name">{post.display_name}</span>
            <span className="post-username">@{post.username}</span>
          </Link>
          <span className="post-time">{timeAgo(post.created_at)}</span>
        </div>
        <h3 className="post-title">{post.title}</h3>
        <p className="post-body">{post.body}</p>
      </div>
    </article>
  );
}
