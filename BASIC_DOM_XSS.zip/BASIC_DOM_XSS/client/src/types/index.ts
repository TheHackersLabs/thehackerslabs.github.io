export interface User {
  id: number;
  username: string;
  email: string;
  display_name: string;
  bio: string;
  avatar_url: string;
  created_at: string;
  followers_count?: number;
  following_count?: number;
  is_following?: boolean;
}

export interface Post {
  id: number;
  user_id: number;
  title: string;
  body: string;
  created_at: string;
  username: string;
  display_name: string;
  avatar_url: string;
}
