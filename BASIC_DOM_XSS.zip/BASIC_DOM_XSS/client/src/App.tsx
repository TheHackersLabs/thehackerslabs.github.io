import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import Layout from './components/Layout';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import FeedPage from './pages/FeedPage';
import ExplorePage from './pages/ExplorePage';
import ProfilePage from './pages/ProfilePage';
import ChallengesPage from './pages/ChallengesPage';
import WriteupPage from './pages/WriteupPage';
import Challenge1 from './pages/challenges/Challenge1';
import Challenge2 from './pages/challenges/Challenge2';
import Challenge3 from './pages/challenges/Challenge3';
import Challenge4 from './pages/challenges/Challenge4';
import Challenge5 from './pages/challenges/Challenge5';
import Challenge6 from './pages/challenges/Challenge6';

export default function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route element={<Layout />}>
            <Route path="/feed" element={<ProtectedRoute><FeedPage /></ProtectedRoute>} />
            <Route path="/explore" element={<ExplorePage />} />
            <Route path="/profile/:id" element={<ProfilePage />} />
            <Route path="/challenges" element={<ChallengesPage />} />
            <Route path="/challenges/1" element={<Challenge1 />} />
            <Route path="/challenges/2" element={<Challenge2 />} />
            <Route path="/challenges/3" element={<Challenge3 />} />
            <Route path="/challenges/4" element={<Challenge4 />} />
            <Route path="/challenges/5" element={<Challenge5 />} />
            <Route path="/challenges/6" element={<Challenge6 />} />
            <Route path="/writeup" element={<WriteupPage />} />
          </Route>
          <Route path="*" element={<Navigate to="/explore" replace />} />
        </Routes>
      </AuthProvider>
    </BrowserRouter>
  );
}
